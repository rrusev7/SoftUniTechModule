import java.util.Scanner;

public class evenNum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Math.abs(Integer.parseInt(scanner.nextLine()));
        boolean even = true;

        while (true) {
            if (n % 2 == 0) {
                System.out.println("The number is: " + n);
                break;
            }else {
                System.out.println("Please write an even number.");
                n = Math.abs(Integer.parseInt(scanner.nextLine()));
            }
        }
    }
}
