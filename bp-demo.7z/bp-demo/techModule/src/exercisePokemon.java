import java.util.Scanner;

public class exercisePokemon {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int pokePowerN = Integer.parseInt(scanner.nextLine());
        int pokeTargetM = Integer.parseInt(scanner.nextLine());
        int exhaustionFactorY = Integer.parseInt(scanner.nextLine());

        int firstPower = pokePowerN;
        int count = 0;

        while (pokePowerN >= pokeTargetM) {
            count++;
            pokePowerN -= pokeTargetM;
            if (pokePowerN == firstPower / 2.00 && exhaustionFactorY != 0) {
                pokePowerN /= exhaustionFactorY;
            }
        }
        System.out.println(pokePowerN);
        System.out.println(count);
    }
}
