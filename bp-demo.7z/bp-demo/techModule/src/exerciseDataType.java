import java.util.Scanner;

public class exerciseDataType {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String word = scanner.nextLine();
        while (!word.equals("END")) {
            word = scanner.nextLine();


        }

    }
}
