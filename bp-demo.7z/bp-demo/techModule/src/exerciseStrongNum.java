import java.util.Scanner;

public class exerciseStrongNum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int input = Integer.parseInt(scanner.nextLine());
        int number = input;

        int sum = 0;
        while (number > 0) {
            int digit = number % 10;
            number /= 10;

            int faktorial = 1;

            for (int i = 1; i <= digit ; i++) {
                faktorial *= i;
            }
            sum += faktorial;
        }
        if (sum == input) {
            System.out.println("yes");
        }else {
            System.out.println("no");
        }
    }
}
