import java.util.Scanner;

public class exerciseLogin {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String userName = scanner.nextLine();

        String password = "";
        int counter = 1;

        for (int i = userName.length() - 1; i >= 0; i--) {
            password += userName.charAt(i);
        }
        String inpuntPass = scanner.nextLine();

        while (!inpuntPass.equals(password)) {
            counter++;
            System.out.println("Incorrect password. Try again.");
            inpuntPass = scanner.nextLine();
            if (counter == 4) {
                break;
            }
        }
        if (inpuntPass.equals(password)) {
            System.out.println("User " + userName + " logged in.");
        } else {
            System.out.println("User " + userName + " blocked!");
        }
    }
}
