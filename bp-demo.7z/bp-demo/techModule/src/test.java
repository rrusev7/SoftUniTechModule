import java.math.BigDecimal;
import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        long n = Long.parseLong(scanner.nextLine());
        BigDecimal sum = new BigDecimal(0);
        for (int i = 0; i < n ; i++) {
            BigDecimal num = new BigDecimal(scanner.nextLine());
            sum = num.add(num);
        }

        System.out.println(sum);
    }
}
