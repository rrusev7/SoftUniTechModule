import java.math.BigDecimal;
import java.util.Scanner;

public class exactSum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int num = Integer.parseInt(scanner.nextLine());
        BigDecimal sum = new BigDecimal(0);

        for (int i = 0; i < num; i++) {
            BigDecimal db = new BigDecimal(scanner.nextLine());
            sum = sum.add(db);
        }
        System.out.println(sum);
    }
}
