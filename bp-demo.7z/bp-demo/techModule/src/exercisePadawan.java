import java.util.Scanner;

public class exercisePadawan {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double budget = Double.parseDouble(scanner.nextLine());
        int students = Integer.parseInt(scanner.nextLine());
        double lightsabersPrice = Double.parseDouble(scanner.nextLine());
        double robesPrice = Double.parseDouble(scanner.nextLine());
        double beltPrice = Double.parseDouble(scanner.nextLine());

        double sabersCount = Math.ceil(students * 1.1) * lightsabersPrice;
        double robesCount = robesPrice * students;
        double beltCount = beltPrice * (students - students / 6);


        double totalPrice = sabersCount + robesCount + beltCount;

        if (budget >= totalPrice) {
            System.out.printf("The money is enough - it would cost %.2flv.", totalPrice);
        }else {
            System.out.printf("Ivan Cho will need %.2flv more.", totalPrice - budget);
        }
    }
}
