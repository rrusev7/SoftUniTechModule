import java.util.Scanner;

public class exercisePrintAndSum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int from = Integer.parseInt(scanner.nextLine());
        int to = Integer.parseInt(scanner.nextLine());

        int sum = 0;

        for (int i = from; i <= to ; i++) {
            System.out.print(i + " ");
            sum += i;
        }
        System.out.println();
        System.out.printf("Sum: %d", sum);
    }
}
