import java.util.Scanner;

public class testVending {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double coins = 0;
        String input = scanner.nextLine();

        while (!input.equals("Start")) {
            if ("0.1".equals(input)
                    || "0.2".equals(input)
                    || "0.5".equals(input)
                    || "1".equals(input)
                    || "2".equals(input)) {
                coins += Double.parseDouble(input);
            } else {
                System.out.printf("Cannot accept %.2f%n", Double.parseDouble(input));

            }
            input = scanner.nextLine();
        }

        input = scanner.nextLine();
        while (!input.equals("End")) {
            if ("Nuts".equals(input)) {
                if (coins < 2.0) System.out.println("Sorry, not enough money");
                    else{
                    System.out.println("Purchased " + input);
                    coins -= 2.0;
                }

            } else if ("Water".equals(input)) {
                if (coins < 0.7) System.out.println("Sorry, not enough money");
                else {
                    System.out.println("Purchased " + input);
                    coins -= 0.7;
                }

            } else if ("Crisps".equals(input)) {
                if (coins < 1.5) System.out.println("Sorry, not enough money");
                else {
                    System.out.println("Purchased " + input);
                    coins -= 1.5;
                }

            } else if ("Soda".equals(input)) {
                if (coins < 0.8) System.out.println("Sorry, not enough money");
                else {
                    System.out.println("Purchased " + input);
                    coins -= 0.8;
                }

            } else if ("Coke".equals(input)) {
                if (coins < 1.0) System.out.println("Sorry, not enough money");
                else {
                    System.out.println("Purchased " + input);
                    coins -= 1.0;
                }

            } else {
                System.out.println("Invalid product");

            }
            input = scanner.nextLine();
        }
        System.out.printf("Change: %.2f", coins);


    }
}
