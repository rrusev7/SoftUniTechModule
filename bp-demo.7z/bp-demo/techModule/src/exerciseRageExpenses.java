import java.util.Scanner;

public class exerciseRageExpenses {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int games = Integer.parseInt(scanner.nextLine());
        double headsetPrice = Double.parseDouble(scanner.nextLine());
        double mousePrice = Double.parseDouble(scanner.nextLine());
        double keyboardPrice = Double.parseDouble(scanner.nextLine());
        double displeyPrice = Double.parseDouble(scanner.nextLine());

        int headCount = games / 2;
        int mouseCount = games / 3;
        int keybordCount = games / 6;
        int displeyCount = games / 12;

        double cost = headCount * headsetPrice
                + mousePrice * mouseCount
                + keyboardPrice * keybordCount
                + displeyCount * displeyPrice;

        System.out.printf("Rage expenses: %.2f lv.", cost);
    }
}
