import java.util.Scanner;

public class exerciseSpice {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int spice = Integer.parseInt(scanner.nextLine());
        int days = 0;
        int totalAmount = 0;

        while (spice >= 100){
            days++;
            totalAmount += (spice - 26);
            spice -= 10;
        }
        if (totalAmount >= 26) {
            totalAmount -= 26;
        }
        System.out.println(days);
        System.out.println(totalAmount);
    }
}

