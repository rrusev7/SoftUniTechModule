import java.util.Scanner;

public class exerciseVacantion {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int person = Integer.parseInt(scanner.nextLine());
        String typeOfGroup = scanner.nextLine().toLowerCase();
        String day = scanner.nextLine().toLowerCase();

        double price = 0;
        double discount = 0;

        if (typeOfGroup.equals("students")) {
            if (day.equals("friday")) {
                price = 8.45 * person;
            } else if (day.equals("saturday")) {
                price = 9.8 * person;
            } else if (day.equals("sunday")) {
                price = 10.46 * person;
            }
        } else if (typeOfGroup.equals("business")) {
            if (day.equals("friday")) {
                price = 10.9 * person;
            } else if (day.equals("saturday")) {
                price = 15.6 * person;
            } else if (day.equals("sunday")) {
                price = 16 * person;
            }
        } else if (typeOfGroup.equals("regular")) {
            if (day.equals("friday")) {
                price = 15 * person;
            } else if (day.equals("saturday")) {
                price = 20 * person;
            } else if (day.equals("sunday")) {
                price = 22.5 * person;
            }
        }
        if (person >= 30 && typeOfGroup.equals("students")) {
            discount = price - (price * 0.15);
        } else if (person >= 100 && typeOfGroup.equals("business")) {
            discount = price - ((price / person) * 10);
        }else if (person >= 10 && person <= 20 && typeOfGroup.equals("regular")) {
            discount = price - (price * 0.05);
        }else {
            discount = price;
        }
        System.out.printf("Total price: %.2f", discount);
    }
}