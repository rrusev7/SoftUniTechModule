import java.util.Scanner;

public class backIn30Min {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int hours = Integer.parseInt(scanner.nextLine());
        int minute = Integer.parseInt(scanner.nextLine()) + 30;

        if (minute > 59) {
            hours += 1;
            minute -= 60;
        }
        if (hours > 23) {
            hours = 0;
        }
        if (minute < 10) {
            System.out.printf("%d:%02d%n", hours, minute);
        }else {
            System.out.printf("%d:%02d", hours, minute);
        }
    }
}
