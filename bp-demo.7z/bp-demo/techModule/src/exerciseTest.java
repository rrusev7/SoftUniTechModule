import java.util.Scanner;

public class exerciseTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String numToText = scanner.nextLine();
        int sum = 0;

        for (int i = 0; i < numToText.length(); i++) {
            sum += numToText.charAt(i) - '0';
        }
        System.out.println(sum);
    }
}
