import javafx.beans.property.IntegerProperty;

import java.util.Scanner;

public class moving {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int weight = Integer.parseInt(scanner.nextLine());
        int lenght = Integer.parseInt(scanner.nextLine());
        int height = Integer.parseInt(scanner.nextLine());
        int totalSpace = weight * lenght * height;

        String input = scanner.nextLine();

        int usedSpace = 0;

        while (!input.equals("Done")) {
            int boxes = Integer.parseInt(input);

            usedSpace += boxes;
            if (usedSpace > totalSpace) {
                System.out.printf("No more free space! You need %d Cubic metres more.", usedSpace - totalSpace);
            }
            input = scanner.nextLine();
        }
        if ( totalSpace > usedSpace) {
            System.out.printf("%d Cubic metres left.", totalSpace - usedSpace);
        }
    }
}
