import java.util.Scanner;

public class newWhile {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numMax = Integer.MIN_VALUE;
        int numMin = Integer.MAX_VALUE;

        while (true) {
            String command = scanner.next();

            if (command.equals("END")){
                break;
            }
            int num = Integer.parseInt(command);

            if (num > numMax){
                numMax = num;
            }
            if (num < numMin){
                numMin = num;
            }
        }
        System.out.printf("Max number: %d%n", numMax);
        System.out.printf("Min number: %d", numMin);
    }
}

