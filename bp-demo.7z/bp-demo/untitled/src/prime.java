import java.util.Scanner;

public class prime {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a positive Number: ");
        int n = Integer.parseInt(scanner.nextLine());

        int divider = 2;
        int maxDivider = (int) Math.sqrt(n);
        boolean prime = true;

        while (prime && (divider <= maxDivider)) {
            if (n % divider == 0) {
                prime = false;
            }
            divider++;
        }
        System.out.println("Prime? " + prime);
    }
}
