import java.util.Scanner;

public class faktoriel {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        long faktoriel = 1;

        while (true) {
            if (n == 1) {
                break;
            }
            faktoriel *= n;
            n--;
        }
        System.out.println("n! = " + faktoriel);
    }
}
