import java.util.Scanner;

public class pbwhile {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String name = scanner.nextLine();
        int grades = 1;
        double sum = 0;

        while (grades <= 12) {
            double grade = Double.parseDouble(scanner.nextLine());

            if (grade >= 4.00) {
                sum += grade;
                grades++;
            }
        }
        double average = sum / 12;

        if (average >= 4.00) {
            System.out.printf("%s graduate. Average grade: %.2f", name, average);
        }
    }
}
