import java.util.Scanner;

public class whileStep {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int steps = 0;
        while (true) {
            String command = scanner.nextLine();

            if (command.equals("Going home")) {
                break;
            }

            int num = Integer.parseInt(command);
            steps += num;

        }
        if (steps >= 10000) {
            System.out.printf("Goal reached! Good job!");
        } else {
            System.out.printf("%d more steps to reach goal.", 10000 - steps);
        }
    }
}
