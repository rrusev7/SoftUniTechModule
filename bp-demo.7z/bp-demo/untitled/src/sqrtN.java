import java.util.Scanner;

public class sqrtN {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("n = ");
        int n = Integer.parseInt(scanner.nextLine());
        System.out.print("m = ");
        int m = Integer.parseInt(scanner.nextLine());
        long result = 1;

        for (int i = 0; i < m ; i++) {
            result *= n;
        }
        System.out.println("n^m = " + result);
    }
}
