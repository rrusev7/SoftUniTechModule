import java.util.Scanner;

public class evenNum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        while (true) {
            System.out.println("Enter even number: ");
            int num = Integer.parseInt(scanner.nextLine());
            if (num % 2 == 0){
                break;
            }
        }

    }
}
