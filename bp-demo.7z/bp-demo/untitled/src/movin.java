import java.util.Scanner;

public class movin {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int widht = Integer.parseInt(scanner.nextLine());
        int lenght = Integer.parseInt(scanner.nextLine());
        int height = Integer.parseInt(scanner.nextLine());

        int totalSpace = widht * lenght * height;
        int freeSpace = 0;

        while (totalSpace > freeSpace) {
            String line = scanner.nextLine();
            if (line.equals("Done")) {
                break;
            }
            int num = Integer.parseInt(line);
            freeSpace += num;
        }
        if (freeSpace < totalSpace) {
            System.out.printf("%d Cubic meters left.\n",totalSpace - freeSpace);
        }else {
            System.out.printf("No more free space! You need %d Cubic meters more.", freeSpace - totalSpace);
        }

    }
}
