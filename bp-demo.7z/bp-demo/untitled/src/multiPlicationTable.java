import java.util.Scanner;

public class multiPlicationTable {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


    }
}


