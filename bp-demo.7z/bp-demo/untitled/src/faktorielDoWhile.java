import java.util.Scanner;

public class faktorielDoWhile {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        long faktoriel = 1;

        do {
            faktoriel *= n;
            n--;
        }while (n > 0);
        System.out.println("n! = " + faktoriel);
    }
}
