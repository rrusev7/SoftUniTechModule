import java.util.Scanner;

public class bus {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int passenger = Integer.parseInt(scanner.nextLine());
        int numStop = Integer.parseInt(scanner.nextLine());

        int totalPassenger = 0;

        for (int i = 1; i <= (numStop * 2); i++) {

            int passengerInOut = Integer.parseInt(scanner.nextLine());
            if (i == 1) {
                totalPassenger += 2 ;
            }else if (i == 2){
                totalPassenger -= 2;
            }
            if (i % 2 == 0) {
                totalPassenger += passengerInOut;
            }else {
                totalPassenger -= passengerInOut;
            }
        }
        System.out.printf("The final number of passengers is : %d \n", passenger + totalPassenger);
    }
}