import java.util.Scanner;

public class intNumber {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        while (n < 1 || n > 100) {
            n = Integer.parseInt(scanner.nextLine());
            if (n > 1 && n < 100) {
                break;
            }
        }
        System.out.println(n);
    }
}
