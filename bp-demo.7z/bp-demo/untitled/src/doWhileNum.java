import java.util.Scanner;

public class doWhileNum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        int m = Integer.parseInt(scanner.nextLine());
        int num = n;
        long product = 1;

        do {
            product *= num;
            num++;
        }while (num <= m);
        System.out.println("product [n..m] = " + product);
    }
}
