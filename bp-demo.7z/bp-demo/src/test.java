import javax.print.attribute.standard.MediaSize;
import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


    }
}


