import java.util.Scanner;

public class exam3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        int group1 = 0;
        int group2 = 0;
        int group3 = 0;
        int totalGrams = 0;

        for (int i = 1; i <= n; i++) {
            double gramsOfFood = Double.parseDouble(scanner.nextLine());

            if (gramsOfFood >= 100 && gramsOfFood < 200){
                group1++;
                totalGrams += gramsOfFood;
            }else if (gramsOfFood >= 200 && gramsOfFood < 300) {
                group2++;
                totalGrams += gramsOfFood;
            }else if (gramsOfFood >= 300 && gramsOfFood < 400){
                group3++;
                totalGrams += gramsOfFood;
            }
        }
        double price = (totalGrams * 12.45) / 1000;

        System.out.printf("Group 1: %d cats.%n", group1);
        System.out.printf("Group 2: %d cats.%n", group2);
        System.out.printf("Group 3: %d cats.%n", group3);
        System.out.printf("Price for food per day: %.2f lv.", price);
    }
}
