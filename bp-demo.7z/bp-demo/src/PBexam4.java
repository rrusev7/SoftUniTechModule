import java.util.Scanner;

public class PBexam4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numCats = Integer.parseInt(scanner.nextLine());

        for (int i = 1; i <= numCats; i++) {
            String firstName = scanner.nextLine();
            String lastName = scanner.nextLine();
            int bornYear = Integer.parseInt(scanner.nextLine());

            System.out.println("" + bornYear + (int)firstName.charAt(0) + (int)lastName.charAt(0) + i );

        }
    }
}
