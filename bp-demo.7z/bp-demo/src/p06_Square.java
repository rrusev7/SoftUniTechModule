import jdk.nashorn.internal.runtime.regexp.joni.ScanEnvironment;

import java.util.Scanner;

public class p06_Square {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        int n = Integer.parseInt(console.nextLine());

        String firstAndLastRow = "";

        for (int i = 0; i < n; i++) {
            firstAndLastRow = firstAndLastRow + "*";
        }
        System.out.println(firstAndLastRow);
        String body = "";

    }
}

