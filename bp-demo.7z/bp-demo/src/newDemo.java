import java.util.Scanner;
import java.util.function.DoublePredicate;

public class newDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double sumFood = Double.parseDouble(scanner.nextLine());
        double sumSouvenir = Double.parseDouble(scanner.nextLine());
        double sumHotel = Double.parseDouble(scanner.nextLine());

        double petrol = 420 * 7 / 100;
        double sumPetrol = petrol * 1.85;

        double totalStay = 3 * sumFood + 3 * sumSouvenir;

        double firstDay = sumHotel * 0.9;
        double secondDay = sumHotel * 0.85;
        double thirdDay = sumHotel * 0.8;

        double totalSum = sumPetrol + firstDay + secondDay + thirdDay + totalStay;

        System.out.printf("Money needed: %.2f", totalSum);

    }

    static String repeatStr(String text, int count) {
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < count; i++) {
            result.append(text);

        }
        return result.toString();
    }
}
