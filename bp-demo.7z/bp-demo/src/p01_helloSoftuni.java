public class p01_helloSoftuni {
    public static void main(String[] args) {

        System.out.println("Hello SoftUni!");
    }
}

