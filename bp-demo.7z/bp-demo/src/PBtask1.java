import java.util.Scanner;

public class PBtask1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double priceBed = Double.parseDouble(scanner.nextLine());
        double priceWC = Double.parseDouble(scanner.nextLine());

        double food = priceWC + (priceWC * 0.25);
        double toys = food - (food * 0.5);
        double doctor = toys + (toys * 0.1);

        double totalCost = priceWC + food + toys + doctor;
        double unforeseenCost = totalCost * 0.05;

        double costForYear = priceBed + 12 * totalCost + 12 * unforeseenCost;

        System.out.printf("%.2f lv.", costForYear);
    }
}
