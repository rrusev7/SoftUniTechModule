import java.util.Scanner;

public class PBexam3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String cat = scanner.nextLine();
        char gender = scanner.nextLine().charAt(0);

        int age = 0;

        if (gender == 'm') {
            if (cat.equals("British Shorthair")) {
                age = 13;
            } else if (cat.equals("Siamese")) {
                age = 15;
            } else if (cat.equals("Persian")) {
                age = 14;
            } else if (cat.equals("Ragdoll")) {
                age = 16;
            } else if (cat.equals("American Shorthair")) {
                age = 12;
            } else if (cat.equals("Siberian")) {
                age = 11;
            } else {
                System.out.printf("%s is invalid cat!", cat);
                return;
            }
        } else if (gender == 'f') {
            if (cat.equals("British Shorthair")) {
                age = 14;
            } else if (cat.equals("Siamese")) {
                age = 16;
            } else if (cat.equals("Persian")) {
                age = 15;
            } else if (cat.equals("Ragdoll")) {
                age = 17;
            } else if (cat.equals("American Shorthair")) {
                age = 13;
            } else if (cat.equals("Siberian")) {
                age = 12;
            } else {
                System.out.printf("%s is invalid cat!", cat);
                return;
            }
        }
        int ageToMount = (age * 12) / 6;

        System.out.printf("%d cat months", ageToMount);
    }
}

