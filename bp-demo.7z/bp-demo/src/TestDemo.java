import java.util.Scanner;
import java.util.function.DoublePredicate;

public class TestDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
int b = Integer.parseInt(scanner.nextLine());
        byte n = 0;
        while (b > n)
            System.out.println(n);
    }
}
