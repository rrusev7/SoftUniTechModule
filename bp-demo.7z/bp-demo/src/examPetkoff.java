import java.util.Scanner;

public class examPetkoff {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double procentFat = Double.parseDouble(scanner.nextLine()) / 100;
        double procentProtein = Double.parseDouble(scanner.nextLine()) / 100;
        double procentCarbohydrates = Double.parseDouble(scanner.nextLine()) / 100;
        double totalCalories = Double.parseDouble(scanner.nextLine()) / 100;
        double procentH20 = Double.parseDouble(scanner.nextLine()) / 100;

        double gramsFat = procentFat * totalCalories / 9;
        double gramsProtein = procentProtein * totalCalories / 4;
        double gramsCarbohydrates = procentCarbohydrates * totalCalories / 4;

        double weight = gramsCarbohydrates + gramsFat + gramsProtein;
        double caloriesGram = totalCalories / weight;

        double gramsFood = caloriesGram * (1 - procentH20);

        System.out.printf("%.4f", gramsFood);
    }
}
