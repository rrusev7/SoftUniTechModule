import java.util.Scanner;

public class SquareArea {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String varna = scanner.nextLine();

        System.out.println(varna);;
    }
}
