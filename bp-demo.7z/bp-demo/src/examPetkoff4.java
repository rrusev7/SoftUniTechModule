import java.util.Scanner;

public class examPetkoff4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        for (int i = 1; i <= n; i++) {
            String firstName = scanner.nextLine();
            String lastName = scanner.nextLine();
            int age = Integer.parseInt(scanner.nextLine());

            System.out.println("" + age + (int)firstName.charAt(0) + (int)lastName.charAt(0) + i);

        }
    }
}
