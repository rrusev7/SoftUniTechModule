import java.util.Scanner;

public class PBexam6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        String line;

        double amount = 0;
        while (!(line = scanner.nextLine()).equals("Adopted")) {
            if (amount == 0) {
                amount = Double.parseDouble(line) * 1000;
                continue;
            }

            int eatten = Integer.parseInt(line);
            amount -= eatten;

            if (amount < 0) {
                break;
            }
        }

        if (amount < 0) {
            System.out.printf("Food is not enough. You need %.0f grams more.", Math.abs(amount));
        } else {
            System.out.printf("Food is enough! Leftovers: %.0f grams.", amount);
        }

    }

}
