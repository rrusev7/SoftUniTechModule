import java.util.Scanner;

public class demo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String town = scanner.nextLine().toLowerCase();
        double value = Double.parseDouble(scanner.nextLine());

        double comision = 0;

        if (town.equals("sofia")) {
            if (value >= 0 && value <= 500) comision = 0.05;
            else if (value > 500 && value <= 1000) comision = 0.07;
            else if (value > 1000 && value <= 10000) comision = 0.08;
            else if (value > 10000) comision = 0.12;
        } else if (town.equals("varna")) {
            if (value >= 0 && value <= 500) comision = 0.045;
            else if (value > 500 && value <= 1000) comision = 0.075;
            else if (value > 1000 && value <= 10000) comision = 0.1;
            else if (value > 10000) comision = 0.13;
        } else if (town.equals("plovdiv")) {
            if (value >= 0 && value <= 500) comision = 0.055;
            else if (value > 500 && value <= 1000) comision = 0.08;
            else if (value > 1000 && value <= 10000) comision = 0.12;
            else if (value > 10000) comision = 0.145;
        }
        if (value >= 0 && town.equals("sofia")|| town.equals("varna") || town.equals("plovdiv")) {
            System.out.printf("%.2f", comision * value);
        }else {
            System.out.println("error");
        }
    }
}


