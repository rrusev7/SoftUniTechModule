import java.util.Scanner;

public class exam6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int kgOfFood = Integer.parseInt(scanner.nextLine()) * 1000;

        double food = 0;
        while (true) {
            String adopted = scanner.nextLine();
            if (adopted.equals("Adopted")){
                break;
            }else {
                food += Integer.parseInt(adopted);
            }
        }
        if (kgOfFood >= food){
            System.out.printf("Food is enough! Leftovers: %.0f grams.", kgOfFood - food);
        }else {
            System.out.printf("Food is not enough. You need %.0f grams more.", food - kgOfFood);
        }
    }
}
