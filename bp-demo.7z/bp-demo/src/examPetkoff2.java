import java.util.Scanner;

public class examPetkoff2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double hourStart = Double.parseDouble(scanner.nextLine());
        double hourPresence = Double.parseDouble(scanner.nextLine());
        double minPresence = Double.parseDouble(scanner.nextLine());
        String day = scanner.nextLine();

        double bonus = 0;

        if (hourPresence >= 17 && hourPresence < 18);
    }
}
