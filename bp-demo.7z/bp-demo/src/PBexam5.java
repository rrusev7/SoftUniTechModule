import java.util.Scanner;

public class PBexam5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < n - 2; i++) { // горната част
            System.out.println(repeatStr(" ", n)
                    + "||"
                    + repeatStr("_", n - 2)
                    + "||");
        }
        System.out.println(repeatStr(" ", n - 1) // горната чупка
                + "//"
                + repeatStr(" ", n)
                + "\\\\");

        for (int rows = 0; rows < n - 4; rows++) { // тялото
            System.out.print(repeatStr(" ", n - 2) + "||" + repeatStr(" ", n + 2) + "||");
            if ((n - 4) % 2 != 0 && rows == (n - 4) / 2) {
                System.out.print("]");
            }

            if ((n - 4) % 2 == 0 && rows == (n - 4) / 2 - 1) {
                System.out.print("]");
            }

            System.out.println();
        }

        System.out.println(repeatStr(" ", n - 1)
                + "\\\\"
                + repeatStr(" ", n)
                + "//");

        for (int i = 0; i < n - 2; i++) {
            System.out.println(repeatStr(" ", n)
                    + "||"
                    + repeatStr("_", n - 2)
                    + "||");
        }
    }

    static String repeatStr(String text, int count) {
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < count; i++) {
            result.append(text);

        }
        return result.toString();
    }
}
