import java.util.Scanner;

public class п09 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String myPassword = "s3cr3t!P@ssw0rd";
        String userPassword = scanner.nextLine();

        if (myPassword.equals(userPassword)){
            System.out.println("Welcome");
        }else {
            System.out.println("Wrong password!");
        }
    }
}
