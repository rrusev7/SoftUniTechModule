import java.util.Scanner;

public class p12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double speed = Double.parseDouble(scanner.nextLine());

        if (speed <= 10){
            System.out.println("slow");
        }else if (speed > 1000){
            System.out.println("extremely fast");
        }else if (speed > 150){
            System.out.println("ultra fast");
        }else if (speed > 50){
            System.out.println("fast");
        }else {
            System.out.println("average");
        }
    }
}
