import java.util.Scanner;

public class p04 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter two integers: ");

        int first = Integer.parseInt(scanner.nextLine());
        int secont = Integer.parseInt(scanner.nextLine());

        if (first > secont){
            System.out.println(first);
        }else {
            System.out.println(secont);
        }
    }
}
