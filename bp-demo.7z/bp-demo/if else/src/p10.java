import java.util.Scanner;

public class p10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int num = Integer.parseInt(scanner.nextLine());

        if (num <= 99){
            System.out.println("Less than 100");
        }else if (num > 200){
            System.out.println("Greater than 200");
        }else {
            System.out.printf("Between 100 and 200");
        }
    }
}
