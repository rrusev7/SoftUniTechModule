import java.util.Scanner;

public class p14 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int hour = Integer.parseInt(scanner.nextLine());
        int minute = Integer.parseInt(scanner.nextLine());
        int timePlusMinute = (hour * 60) + minute + 15;

        hour = timePlusMinute / 60;
        if(hour >= 24){
            hour = hour%24;
        }
        minute = timePlusMinute %60;

        System.out.printf("%d:%02d", hour, minute);
    }
}
