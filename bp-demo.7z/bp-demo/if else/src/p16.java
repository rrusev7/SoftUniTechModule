import java.util.Scanner;

public class p16 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int num = Integer.parseInt(scanner.nextLine());

        if (num == 0) {
            System.out.println("zero");
        } else if (num == 1) {
            System.out.println("one");
        } else if (num == 2) {
            System.out.println("two");
        } else if (num == 3) {
            System.out.println("three");
        } else if (num == 4) {
            System.out.println("four");
        } else if (num == 5) {
            System.out.println("five");
        } else if (num == 6) {
            System.out.println("six");
        } else if (num == 7) {
            System.out.println("seven");
        } else if (num == 8) {
            System.out.println("eight");
        } else if (num == 9) {
            System.out.println("nine");
        } else if (num == 10) {
            System.out.println("ten");
        } else if (num == 11) {
            System.out.println("eleven");
        } else if (num == 12) {
            System.out.println("twelve");
        } else if (num == 13) {
            System.out.println("thirteen");
        }else {
            System.out.println("invalid number");
        }
    }
}