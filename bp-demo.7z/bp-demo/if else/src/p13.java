import java.util.Scanner;

public class p13 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String figure = scanner.nextLine().toLowerCase();
        double area = 0;

        switch (figure){
            case "square":
                double squreSide = Double.parseDouble(scanner.nextLine());
                area = squreSide * squreSide;
                break;
            case "rectangle":
                double rectagleSideA = Double.parseDouble(scanner.nextLine());
                double rectagleSideB = Double.parseDouble(scanner.nextLine());
                area = rectagleSideA * rectagleSideB;
                break;
            case "circle":
                double radius = Double.parseDouble(scanner.nextLine());
                area = radius * radius * Math.PI;
                break;
            case "triagle":
                double triagleSideA = Double.parseDouble(scanner.nextLine());
                double triagleSideB = Double.parseDouble(scanner.nextLine());
                area = (triagleSideA * triagleSideB) / 2;
        }
        System.out.printf("%.3f", area);
    }
}
