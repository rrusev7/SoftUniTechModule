import java.util.Scanner;

public class p08n {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double conversionNumber = Double.parseDouble(scanner.nextLine());
        String input = scanner.nextLine().toLowerCase();
        String output = scanner.nextLine().toLowerCase();

        double m = 1.0;
        double mm = 1000;
        double cm = 100;
        double mi = 0.000621371192;
        double in = 39.3700787;
        double km = 0.001;
        double ft = 3.2808399;
        double yd = 1.0936133;

        if (input.equals("m")) {
            conversionNumber = conversionNumber / m;
        } else if (input.equals("mm")) {
            conversionNumber = conversionNumber / mm;
        } else if (input.equals("cm")) {
            conversionNumber = conversionNumber / cm;
        } else if (input.equals("mi")) {
            conversionNumber = conversionNumber / mi;
        } else if (input.equals("in")){
            conversionNumber = conversionNumber / in;
        } else if (input.equals("km")) {
            conversionNumber = conversionNumber / km;
        } else if (input.equals("ft")) {
            conversionNumber = conversionNumber / ft;
        } else if (input.equals("yd")) {
            conversionNumber = conversionNumber / yd;
        } else {
            System.out.printf("Wrong Input");
        }
        if (output.equals("m")){
            conversionNumber = conversionNumber * m;
        }else if (output.equals("mm")){
            conversionNumber = conversionNumber * mm;
        }else if (output.equals("cm")){
            conversionNumber = conversionNumber * cm;
        }else if (output.equals("mi")){
            conversionNumber = conversionNumber * mi;
        }else if (output.equals("in")){
            conversionNumber = conversionNumber * in;
        }else if (output.equals("km")){
            conversionNumber = conversionNumber * km;
        }else if (output.equals("ft")){
            conversionNumber = conversionNumber * ft;
        }else if (output.equals("yd")){
            conversionNumber = conversionNumber *yd;
        }else {
            System.out.printf("Wrong Output");
        }
        System.out.printf("%.8f", conversionNumber);
    }
}
