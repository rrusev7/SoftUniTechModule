import java.util.Scanner;

public class p02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String product = scanner.nextLine().toLowerCase();
        String town = scanner.nextLine().toLowerCase();
        double qwerty = Double.parseDouble(scanner.nextLine());

        if (town.equals("sofia")) {
            if (product.equals("coffee")) {
                System.out.println(0.5 * qwerty);
            } else if (product.equals("water")) {
                System.out.println(0.8 * qwerty);
            } else if (product.equals("beer")) {
                System.out.println(1.2 * qwerty);
            } else if (product.equals("sweets")) {
                System.out.println(1.45 * qwerty);
            } else if (product.equals("peanuts")) {
                System.out.println(1.60 * qwerty);
            }
        }
        if (town.equals("varna")) {
            if (product.equals("coffee")) {
                System.out.println(0.45 * qwerty);
            }
            else if (product.equals("water")) {
                System.out.println(0.7 * qwerty);
            }
            else if (product.equals("beer")) {
                System.out.println(1.10 * qwerty);
            }
            else if (product.equals("sweets")) {
                System.out.println(1.35 * qwerty);
            }
            else if (product.equals("peanuts")) {
                System.out.println(1.55 * qwerty);
            }
        }
        if (town.equals("plovdiv")) {
             if (product.equals("coffee")) {
                System.out.println(0.40 * qwerty);
            }
            else if (product.equals("water")) {
                System.out.println(0.7 * qwerty);
            }
            else if (product.equals("beer")) {
                System.out.println(1.15 * qwerty);
            }
            else if (product.equals("sweets")) {
                System.out.println(1.30 * qwerty);
            }
            else if (product.equals("peanuts")) {
                System.out.println(1.50 * qwerty);
            }
        }
    }
}
