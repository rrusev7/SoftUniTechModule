import java.util.Scanner;

public class p12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String years = scanner.nextLine();
        int holidays = Integer.parseInt(scanner.nextLine());
        int weekendsAtHome = Integer.parseInt(scanner.nextLine());

        int weekends = 48;

        double sofia = (weekends - weekendsAtHome) * 0.75;
        double activeHolidays = (holidays * 2.0) / 3;
        double playGame = sofia + activeHolidays + weekendsAtHome;

        if (years.equals("normal")){
            System.out.printf("%.2f",Math.floor(playGame), playGame);
        }else if (years.equals("leap")){
            System.out.printf("%.2f",Math.floor(playGame), playGame);
        }

    }
}
