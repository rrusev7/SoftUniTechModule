import java.util.Scanner;

public class pp07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String product = scanner.nextLine();
        String day = scanner.nextLine();
        double quantity = Double.parseDouble(scanner.nextLine());

        double price = 0;

        if (day.equalsIgnoreCase("monday") || day.equalsIgnoreCase("tuesday") || day.equalsIgnoreCase("wednesday")
                || day.equalsIgnoreCase("thursday") || day.equalsIgnoreCase("friday")){
            if (product.equals("banana")) price = 2.5;
                else if (product.equals("apple")) price = 1.2;
                else if (product.equals("orange")) price = 0.85;
                else if (product.equals("grapefruit")) price = 1.45;
                else if (product.equals("kiwi")) price = 2.7;
                else if (product.equals("pineapple")) price = 5.5;
                else if (product.equals("grapes")) price = 3.85;
            }
        else if (day.equalsIgnoreCase("saturday") || day.equalsIgnoreCase("sunday")){
            if (product.equals("banana")) price = 2.7;
            else if (product.equals("apple")) price = 1.25;
            else if (product.equals("orange")) price = 0.9;
            else if (product.equals("grapefruit")) price = 1.6;
            else if (product.equals("kiwi")) price = 3;
            else if (product.equals("pineapple")) price = 5.6;
            else if (product.equals("grapes")) price = 4.2;
        }else {
            System.out.println("error");
        }
        double sum = price * quantity;
        if (price == 0){
            System.out.println("error");;
        }else {
            System.out.printf("%.2f", sum);;
        }
    }
}
