import java.util.Scanner;

public class p11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String projection = scanner.nextLine();
        int rows = Integer.parseInt(scanner.nextLine());
        int columns = Integer.parseInt(scanner.nextLine());
        int seats = rows * columns;
        double price = 0;

       switch (projection){
           case "Premiere":
               price = 12.00;
               break;
           case "Normal":
               price = 7.5;
               break;
           case "Discount":
               price = 5.00;
               break;
       }
       double total = seats * price;
        System.out.printf("%.2f", total);
    }
}
