import java.util.Scanner;

public class p04 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String value = scanner.nextLine();

        if(value.equals("banana") || value.equals("apple") || value.equals("kiwi")
        || value.equals("cherry") || value.equals("lemon") || value.equals("grapes")){
            System.out.println("fruit");
        }else if (value.equals("tomato") || value.equals("cucumber")
                || value.equals("pepper") || value.equals("carrot")){
            System.out.println("vegetable");
        }else {
            System.out.println("unknown");
        }
    }
}
