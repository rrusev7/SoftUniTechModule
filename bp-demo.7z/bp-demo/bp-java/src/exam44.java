import java.util.Scanner;

public class exam44 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int mount = Integer.parseInt(scanner.nextLine());

        double Electricity = 0;
        double water = 20 * mount;
        double internet = 15 * mount;

        for (int i = 1; i <= mount; i++) {
            double tok = Double.parseDouble(scanner.nextLine());
            Electricity += tok;
        }
        double other = (Electricity + water + internet) * 1.2;
        System.out.printf("Electricity: %.2f lv%n", Electricity);
        System.out.printf("Water: %.2f lv%n", water);
        System.out.printf("Internet: %.2f lv%n", internet);
        System.out.printf("Other: %.2f lv%n", other);
        System.out.printf("Average: %.2f lv", ((Electricity + water + internet + other)) / mount);
    }
}
