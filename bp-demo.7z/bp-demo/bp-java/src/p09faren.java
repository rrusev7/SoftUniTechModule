import java.util.Scanner;

public class p09faren {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double celsius = Double.parseDouble(scanner.nextLine());

        double faremha = celsius * 1.8 + 32;

        System.out.printf("%.2f", faremha);
    }
}
