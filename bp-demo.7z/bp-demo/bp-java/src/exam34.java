import java.util.Scanner;

public class exam34 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numDwarf = Integer.parseInt(scanner.nextLine());
        int sum = Integer.parseInt(scanner.nextLine());
        double price = 0;

        for (int i = 1; i <= numDwarf; i++) {
            String gift = scanner.nextLine();
            if (gift.equals("sand clock")) {
                price = price + 2.2;
            }else if (gift.equals("magnet")) {
                price = price + 1.5;
            }else if (gift.equals("cup")) {
                price = price + 5;
            }else if (gift.equals("t-shirt")) {
                price = price + 10.00;
            }
        }

        if (sum > price) {
            System.out.printf("Santa Claus has %.2f more leva left!%n", sum - price);
        } else {
            System.out.printf("Santa Claus will need %.2f more leva.", price - sum);
        }
    }
}
