import java.util.Scanner;

public class exam3333 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String season = scanner.nextLine();
        double kmForMount = Double.parseDouble(scanner.nextLine());

        double sum = 0;

        if (season.equals("Spring") || season.equals("Autumn")) {
            if (kmForMount <= 5000) {
                sum = 0.75;
            } else if (kmForMount > 5000 && kmForMount <= 10000) {
                sum = 0.95;
            } else if (kmForMount <= 20000) {
                sum = 1.45;
            }
        } else if (season.equals("Summer")) {
            if (kmForMount <= 5000) {
                sum = 0.90;
            } else if (kmForMount > 5000 && kmForMount <= 10000) {
                sum = 1.10;
            } else if (kmForMount <= 20000) {
                sum = 1.45;
            }
        } else if (season.equals("Winter")) {
            if (kmForMount <= 5000) {
                sum = 1.05;
            } else if (kmForMount > 5000 && kmForMount <= 10000) {
                sum = 1.25;
            } else if (kmForMount <= 20000) {
                sum = 1.45;
            }
        }

        double salary = sum * kmForMount * 4;
        double tax = salary - (salary * 0.1);
        System.out.printf("%.2f", tax);
    }
}