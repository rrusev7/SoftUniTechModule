import java.util.Scanner;

public class p12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double USD = Double.parseDouble(scanner.nextLine());
        double fix = 1.79549;

        double BGN = USD * fix;

        System.out.printf("%.2f", BGN);
    }
}
