import java.net.DatagramPacket;
import java.util.Scanner;

public class exam3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numDays = Integer.parseInt(scanner.nextLine());
        String room = scanner.nextLine();
        String evaluation = scanner.nextLine();
        double price = 0;

        double roomForOnePerson = 18.00;
        double apartament = 25.00;
        double presidenApart = 35.00;

        if (room.equals("room for one person")){
            price = roomForOnePerson * numDays;
        }
        else if (room.equals("apartment")){
            if (numDays <= 10){
                price = (apartament * (numDays - 1) - (apartament * (numDays - 1) * 0.30));
            }else if (numDays > 15){
                price = (apartament * (numDays - 1)) - (apartament * (numDays - 1) * 0.5);
            }else {
                price = (apartament * (numDays - 1)) - (apartament * (numDays - 1) * 0.35);
            }
        }else if (room.equals("president apartment")){
            if (numDays <= 10){
                price = (presidenApart * (numDays - 1)) - (presidenApart * (numDays - 1) * 0.10);
            }else if (numDays > 15){
                price = (presidenApart * (numDays - 1)) - (presidenApart * (numDays - 1) * 0.2);
            }else {
                price = (presidenApart * (numDays - 1)) - (presidenApart * (numDays - 1) * 0.15);
            }
        }
        if (evaluation.equals("positive")){
            price = (price * 0.25) + price;
        }else if (evaluation.equals("negative")){
            price = price - (price * 0.1);
        }
        System.out.printf("%.2f", price);
    }
}
