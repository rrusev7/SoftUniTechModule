import java.util.Scanner;

public class birthday {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int length = Integer.parseInt(scanner.nextLine());
        int widrh = Integer.parseInt(scanner.nextLine());
        int height = Integer.parseInt(scanner.nextLine());
        double parcent = Double.parseDouble(scanner.nextLine());

        double volume = length * widrh * height;
        double litres = volume * 0.001;
        double parcentRes = parcent * 0.01;
        double result = litres * (1-parcentRes);

        System.out.printf("%.3f", result);
    }
}
