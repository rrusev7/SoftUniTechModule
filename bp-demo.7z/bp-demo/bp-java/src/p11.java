import java.util.Scanner;

public class p11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double rad = Double.parseDouble(scanner.nextLine());

        double deg = rad * 180/Math.PI;
        double result = Math.round(deg);

        System.out.printf("%.0f", result);
    }
}
