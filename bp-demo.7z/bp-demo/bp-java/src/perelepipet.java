import java.util.Scanner;

public class perelepipet {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        System.out.println("+"
                + repeatStr("~", n - 2)
                + "+"
                + repeatStr(".", n * 2 + 1));

        for (int i = 0; i < n * 2 + 1; i++) {
            System.out.println("|"
                    + repeatStr(".", i)
                    + "\\"
                    + repeatStr("~", n - 2)
                    + "\\"
                    + repeatStr(".", n * 2 - i));
        }

        for (int i = 0; i < n * 2 + 1; i++) {
            System.out.println(repeatStr(".", i)
                    + "\\"
                    + repeatStr(".", n * 2 - i)
                    + "|"
                    + repeatStr("~", n - 2)
                    + "|");
        }

        System.out.println(repeatStr(".", n * 2 + 1)
                + "+"
                + repeatStr("~", n - 2)
                + "+");


    }

    static String repeatStr(String text, int count) {
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < count; i++) {
            result.append(text);

        }
        return result.toString();
    }
}
