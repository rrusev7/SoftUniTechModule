import java.util.Scanner;

public class p08triagle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double hight = Double.parseDouble(scanner.nextLine());
        double weight = Double.parseDouble(scanner.nextLine());

        double area = hight * weight / 2;

        System.out.printf("%.2f", area);
    }
}
