import java.util.Scanner;

public class P06 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double r = Double.parseDouble(scanner.nextLine());
        double area = Math.PI * r * r;
        double perimetres = 2* Math.PI * r;

        System.out.println(area);
        System.out.println(perimetres);
    }
}
