import java.util.Scanner;

public class dl {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double inc = Double.parseDouble(scanner.nextLine());
        double cm = inc * 2.54;

        System.out.println(cm);

    }
}
