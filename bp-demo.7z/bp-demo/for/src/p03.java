import java.util.Scanner;

public class p03 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        for (char i = 'a'; i <= 'z'; i++) {
            System.out.println(i);
        }
    }
}
