import java.util.Scanner;

public class p07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int number = Integer.parseInt(scanner.nextLine());

        int leftSide = 0;
        int rightSide = 0;

        for (int i = 0; i < number; i++) {
            int sum = Integer.parseInt(scanner.nextLine());
            leftSide += sum;
        }
        for (int i = 0; i < number; i++) {
            int sum = Integer.parseInt(scanner.nextLine());
            rightSide += sum;
        }
        if (leftSide == rightSide){
            System.out.printf("Yes, sum = %d", leftSide);;
        }else{
            System.out.printf("No, diff = %d", Math.abs(leftSide - rightSide));;
        }
    }
}
