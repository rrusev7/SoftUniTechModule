import java.util.Scanner;

public class p06 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        int min = Integer.MAX_VALUE;

        for (int i = 0; i < n; i++) {
            int sum = Integer.parseInt(scanner.nextLine());

            if (sum <= min) {
                min = sum;
            }

        }
        System.out.println(min);
    }
}
