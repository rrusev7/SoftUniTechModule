import java.util.Scanner;

public class orders {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String order = scanner.nextLine();
        int pcs = Integer.parseInt(scanner.nextLine());

        totalSum(order, pcs);


    }

    static void totalSum(String order, int pcs) {

        double price = 0;
        switch (order) {
            case "coffee":
                price = 1.50;
                System.out.printf("%.2f", pcs * price);
                break;
            case "water":
                price = 1.00;
                System.out.printf("%.2f", pcs * price);
                break;
            case "coke":
                price = 1.40;
                System.out.printf("%.2f", pcs * price);
                break;
            case "snacks":
                price = 2.00;
                System.out.printf("%.2f", pcs * price);
                break;
        }
    }
}