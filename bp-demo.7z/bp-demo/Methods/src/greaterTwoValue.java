import java.util.Scanner;

public class greaterTwoValue {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String command = scanner.nextLine().toLowerCase();

        switch (command){
            case "int":
                int value1 = Integer.parseInt(scanner.nextLine());
                int value2 = Integer.parseInt(scanner.nextLine());
                int greater = getMax(value1,value2);
                System.out.println(greater);
                break;
            case "char":
                char char1 = scanner.nextLine().charAt(0);
                char char2 = scanner.nextLine().charAt(0);
                char greate = getMax(char1, char2);
                System.out.println(greate);
                break;
            case "string":
                String str = scanner.nextLine();
                String str2 = scanner.nextLine();
                String greaterr = getMax(str, str2);
                System.out.println(greaterr);
                break;
        }

    }
    static  int getMax (int first, int second) {
        if (first > second) {
            return first;
        }
        return second;
    }
    static char getMax (char first, char second) {
        if (first > second) {
            return first;
        }
        return second;
    }
    static String getMax (String first, String second) {
        if (first.compareTo(second) >= 0) {
            return first;
        }
        return second;
    }
}
