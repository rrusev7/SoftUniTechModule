import java.util.Scanner;

public class repeatString {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String command = scanner.nextLine();
        int count = Integer.parseInt(scanner.nextLine());

        repeatStr(command, count);

    }
   static String repeatStr(String text, int count) {
            String result = "";

            for (int i = 0; i < count; i++) {
                System.out.print(text);

            }
            return result;
        }
}
