import java.util.Scanner;

public class mathPower {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double a = Double.parseDouble(scanner.nextLine());
        int b = Integer.parseInt(scanner.nextLine());

        System.out.printf("%.0f", printMathPower(a, b));
    }
    static double printMathPower (double number, int power) {
        double result = (Math.pow(number, power));

        return result;
    }
}
