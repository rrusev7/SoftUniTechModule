import java.util.Scanner;

public class examKaminoFactory {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int sequenceLeght = Integer.parseInt(scanner.nextLine());
        String line = scanner.nextLine();

        int bestLenght = 0;
        String bestDNA = "";
        int bestIndex = 0;
        int bestSum = 0;
        int counter = 0;
        int bestCounter = 0;

        while (!line.equals("Clone them!")) {

            counter++;
            String sequance = line.replaceAll("!+", "");
            String[] dns = sequance.split("0");

            int maxLenght = 0;
            int sum = 0;
            String localDNA = "";

            for (int i = 0; i < dns.length; i++) {
                if (dns[i].length() > maxLenght) {
                    maxLenght = dns[i].length();
                    localDNA = dns[i];
                }
                sum = sum + dns[i].length();
            }
            int beginIndex = sequance.indexOf(localDNA);

            if (maxLenght > bestLenght) {
                bestLenght = maxLenght;
                bestDNA = sequance;
                bestIndex = beginIndex;
                bestSum = sum;
                bestCounter = counter;
            } else if (maxLenght == bestLenght &&
                    (beginIndex < bestIndex || sum > bestSum)) {
                bestLenght = maxLenght;
                bestDNA = sequance;
                bestIndex = beginIndex;
                bestSum = sum;
                bestCounter = counter;
            } else if (counter == 1) {
                bestLenght = maxLenght;
                bestDNA = sequance;
                bestIndex = beginIndex;
                bestSum = sum;
                bestCounter = counter;
            }

            line = scanner.nextLine();
        }
        System.out.println(String.format("Best DNA sample %d with sum: %d.", bestCounter, bestSum));

        for (int i = 0; i < bestDNA.length(); i++) {
            System.out.print(bestDNA.charAt(i) + " ");
        }
    }
}
