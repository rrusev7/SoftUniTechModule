import java.util.Scanner;

public class exerciseMagicSum {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String[] strNum = scanner.nextLine().split(" ");
        
        int[] numbers = new int[strNum.length];

        for (int i = 0; i < strNum.length; i++) {
            numbers[i] = Integer.parseInt(strNum[i]);
        }
        
        int inputSum = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < numbers.length; i++) {
            for (int j = i + 1; j < numbers.length; j++) {
                int sum = numbers[i] + numbers [j];
                if (sum == inputSum) {
                    System.out.println(numbers[i] + " " + numbers[j]);
                }
            }
        }
    }
}
