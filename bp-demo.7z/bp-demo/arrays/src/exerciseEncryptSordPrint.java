import java.util.Scanner;

public class exerciseEncryptSordPrint {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int strNum = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < strNum; i++) {
           String word = scanner.nextLine();
        }
    }
}
