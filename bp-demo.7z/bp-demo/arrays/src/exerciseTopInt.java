import java.util.Scanner;

public class exerciseTopInt {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] strNum = scanner.nextLine().split(" ");

        int[] numbers = new int[strNum.length];

        for (int i = 0; i < strNum.length; i++) {
            numbers[i] = Integer.parseInt(strNum[i]);
        }

        for (int i = 0; i < numbers.length; i++) {
            for (int j = i + 1; j < numbers.length; j++) {
                if (numbers[i] <= numbers[j]) {
                    break;
                }
                if (numbers[i] > numbers[j]) {
                    System.out.print(numbers[i] + " ");
                    break;
                }
            }
            System.out.print(numbers[numbers.length - 1]);
        }
    }
}