import java.util.Scanner;

public class exerciseArrayRotation {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String[] strNum = scanner.nextLine().split(" ");

        int rotattion = Integer.parseInt(scanner.nextLine());

        rotattion = rotattion % strNum.length;

        for (int i = 0; i < rotattion; i++) {
            String elements = strNum[0];
            for (int j = 0; j <strNum.length - 1 ; j++) {
                strNum[j] = strNum[j + 1];
            }
            strNum [strNum.length - 1] = elements;
        }
        for (int i = 0; i < strNum.length; i++) {
            System.out.print(strNum[i] + " ");
        }
    }
}
