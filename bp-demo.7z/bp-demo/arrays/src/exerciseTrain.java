import java.util.Scanner;

public class exerciseTrain {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int numTrain = Integer.parseInt(scanner.nextLine());
        int[] getOn = new int[numTrain];

        int count = 0;
        int sum = 0;
        for (int i = 0; i < numTrain; i++) {
            getOn[i] = Integer.parseInt(scanner.nextLine());
            count = getOn[i];
            System.out.print(count + " ");
            sum += count;
        }
        System.out.println();
        System.out.println(sum);
    }
}
