import java.util.Arrays;
import java.util.Scanner;

public class evenAndOdd {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] numbers = Arrays.stream(scanner.nextLine().split(" ")).mapToInt(e -> Integer.parseInt(e)).toArray();

        int evenNum = 0;
        int oddNum = 0;

        for (int number : numbers) {
            if (number % 2 == 0) {
                evenNum += number;
            }else {
                oddNum += number;
            }
        }
        int diff = evenNum - oddNum;
        System.out.println(diff);
    }
}
