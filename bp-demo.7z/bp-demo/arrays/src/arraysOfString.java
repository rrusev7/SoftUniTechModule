import java.util.Scanner;

public class arraysOfString {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


    }
}
