import java.util.Scanner;

public class exerciseMaxSequence {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String[] strNum = scanner.nextLine().split(" ");

        int[] number = new int[strNum.length];

        for (int i = 0; i < strNum.length; i++) {
            number[i] = Integer.parseInt(strNum[i]);
        }
        int counter = 1;
        int maxLength = 1;
        int bestIndex = 0;
        for (int i = 0; i < number.length - 1; i++) {
            if (number[i] == number[i + 1]) {
                counter++;
            } else {
                counter = 1;
            }
            if (counter > maxLength) {
                maxLength = counter;
                bestIndex = i + 1;
            }
        }
        int begin = (bestIndex - maxLength) + 1;

        for (int i = begin; i < begin + maxLength ; i++) {
            System.out.print(number[i] + " ");
        }
        System.out.println();
    }
}
