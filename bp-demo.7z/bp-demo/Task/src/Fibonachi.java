import java.util.Scanner;

public class Fibonachi {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        int result = 0;

        for (int i = 0; i < n; i++) {
            result = (i - 1) + i;
            System.out.println(result);
            
        }
    }
}

