import java.util.Scanner;

public class ifProblem3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        int bonus = 0;

        if (n >= 1 && n <= 3){
            bonus = n * 10;
        }else if (n >= 4 && n <= 6){
            bonus = n * 100;
        }else if (n >= 7 && n <= 9){
            bonus = n * 1000;
        }else {
            System.out.printf("Invalid number");
        }
        System.out.println(bonus);
    }
}
