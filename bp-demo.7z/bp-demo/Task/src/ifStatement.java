import java.util.Scanner;

public class ifStatement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int a = Integer.parseInt(scanner.nextLine());
        int b = Integer.parseInt(scanner.nextLine());
        int sum = a + b;

        if (a != b) {
            System.out.println(sum * 2);
        }else {
            System.out.println(sum);
        }
    }
}
