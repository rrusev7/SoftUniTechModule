import java.util.Scanner;

public class sumOfNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int sum = 4;
        int sum2 = 5;
        int sum3 = 2;

        System.out.println(sum + sum2 + sum3);
    }
}
