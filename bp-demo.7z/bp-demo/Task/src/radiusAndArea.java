import java.util.Scanner;

public class radiusAndArea {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double r = Double.parseDouble(scanner.nextLine());
        double radius = r * r;
        double area = Math.PI * r;

        System.out.printf("%.2f%n", radius);
        System.out.printf("%.2f", area);

    }
}
