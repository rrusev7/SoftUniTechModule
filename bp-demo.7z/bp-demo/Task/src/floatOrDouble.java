public class floatOrDouble {
    public static void main(String[] args) {

        double first = 34.567839023;
        double second = 12.345;
        double third = 8923.1234857;
        double four = 3456.091;

        System.out.println(first);
        System.out.println(second);
        System.out.println(third);
        System.out.println(four);


    }
}
