public class dataTypes {
    public static void main(String[] args) {

        System.out.println("Rousse");
    }
}
