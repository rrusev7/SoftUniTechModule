import java.util.Scanner;

public class playCards {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String card = scanner.nextLine();

        if (card.equals("2")){
            System.out.println(card);
        }else if (card.equals("3")){
            System.out.println(card);
        }else if (card.equals("4")){
            System.out.println(card);
        }else if (card.equals("5")){
            System.out.println(card);
        }else if (card.equals("6")){
            System.out.println(card);
        }else if (card.equals("7")) {
            System.out.println(card);
        }else if (card.equals("8")) {
            System.out.println(card);
        }else if (card.equals("9")) {
            System.out.println(card);
        }else if (card.equals("10")) {
            System.out.println(card);
        }else if (card.equals("J")) {
            System.out.println(card);
        }else if (card.equals("Q")) {
            System.out.println(card);
        }else if (card.equals("K")) {
            System.out.println(card);
        }else if (card.equals("A")) {
            System.out.println(card);
        }else {
            System.out.println("Invalid card");
        }
    }
}
