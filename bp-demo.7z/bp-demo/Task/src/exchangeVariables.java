public class exchangeVariables {
    public static void main(String[] args) {

        String firstMaintenance = "Hello and World";
        String secondMaintenance = "Hello and World";
        Object allMaintenance = firstMaintenance + " " + secondMaintenance;

    }
}
