import java.util.Scanner;

public class declareVariables {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int firstNumber = 52130;
        byte secondNumber = -115;
        int thirdNumber = 4825932;
        byte fourNumber = 97;
        int fiveNumber = -10000;

        System.out.println(firstNumber);
        System.out.println(secondNumber);
        System.out.println(thirdNumber);
        System.out.println(fourNumber);
        System.out.println(fiveNumber);


    }
}
